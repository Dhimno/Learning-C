/* File       : main.c */
/* Deskripsi  : aplikasi driver ADT list berkait, representasi fisik pointer */
/* NIM/Nama   : 24060124120010/Dhimas Reza Nafi Wahyudi */
/* Tanggal    : 9 November 2025 */
/***********************************/

#include <stdio.h>
#include <stdlib.h>
#include "list1.h"
#include "list1.c"

int main() {
    // kamus
    List1 L;
    address P;
    infotype V;
    address A;

    // algoritma
    printf("==================================================\n");
    printf("                     MAIN PROGRAM        \n");
    printf("==================================================\n");
    CreateList(&L);
    PrintList(L);
    printf("Apakah list kosong? %d\n", IsEmptyList(L));
    printf("==================================================\n");

    printf("Menambahkan elemen di awal dan akhir :\n");
    InsertVFirst(&L, 'A');
    InsertVLast(&L, 'B');
    InsertVLast(&L, 'C');
    InsertVLast(&L, 'D');
    printf("Isi list: ");
    PrintList(L);
    printf("==================================================\n");

    printf("Menambahkan elemen di awal :\n");
    InsertVFirst(&L, 'Z');
    PrintList(L);
    printf("==================================================\n");

    printf("Jumlah elemen dalam list: %d\n", NbElm(L));
    printf("==================================================\n");

    printf("Menghapus elemen pertama :\n");
    DeleteVFirst(&L, &V);
    printf("Elemen yang dihapus: %c\n", V);
    printf("Isi list sekarang: ");
    PrintList(L);

    printf("==================================================\n");
    printf("Menghapus elemen terakhir :\n");
    DeleteVLast(&L, &V);
    printf("Elemen yang dihapus: %c\n", V);
    printf("Isi list sekarang: ");
    PrintList(L);
    printf("==================================================\n");


    printf("Mencari elemen 'B'...\n");
    SearchX(L, 'B', &A); 
    if (A != NIL) {
        printf("Elemen 'B' ditemukan di alamat.\n");
    } else {
        printf("Elemen 'B' tidak ditemukan.\n");
    }
    printf("==================================================\n"); 

    printf("Isi list sebelum UpdateX:\n");
    PrintList(L);

    printf("\nMengganti elemen pertama 'B' menjadi 'X':\n");
    UpdateX(&L, 'B', 'X');

    printf("Isi list setelah UpdateX:\n");
    PrintList(L);
    printf("==================================================\n");

    printf("Menghapus semua elemen satu per satu :\n");
    while (!IsEmptyList(L)) {
        DeleteVFirst(&L, &V);
        printf("Menghapus: %c\n", V);
    }
    printf("List akhir:\n");
    PrintList(L);
    printf("Apakah list kosong? %d\n", IsEmptyList(L));
    printf("==================================================\n");

    return 0;
}
