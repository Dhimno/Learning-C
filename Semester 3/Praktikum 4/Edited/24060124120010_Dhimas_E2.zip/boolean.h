/*File    	: boolean.h*/
/*Deskripsi : Header fungsi boolean */
/*Dibuat    : Dhimas Reza Nafi Wahyudi (24060124120010)*/
/* Tanggal   : Kamis, 25 September 2025 */

/* Kamus */
#ifndef boolean_H
#define boolean_H

#define true 1
#define false 0
#define boolean unsigned char

#endif

