/*  Program    : boolean.h */
/*  Deskripsi  : Header file modul boolean. */
/*  NIM/Nama   : 24060124120010/Dhimas Reza Nafi Wahyudi */
/*  Tanggal    : 20 November 2025 */

#ifndef boolean_H
#define boolean_H 

#define false 0
#define true 1
#define boolean unsigned char 

#endif
