/*File    	: boolean.h*/
/*Deskripsi : Header fungsi boolean */
/*Dibuat    : 24060124120010/Dhimas Reza Nafi Wahyudi*/
/* Tanggal   : 9 Oktober 2025*/

/* Kamus */
#ifndef boolean_H
#define boolean_H

#define true 1
#define false 0
#define boolean unsigned char

#endif

